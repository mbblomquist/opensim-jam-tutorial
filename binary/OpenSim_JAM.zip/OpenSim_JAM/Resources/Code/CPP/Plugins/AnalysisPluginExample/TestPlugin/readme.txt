To test the example plugin from the command prompt, type:

analyze -L osimPlugin -S subject01_Setup_AnalysisPluginTemplate.xml

Then compare the output to that in the ExpectedResults.